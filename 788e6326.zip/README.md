# MetroTube Client - WITH AUTHENTICATION

**A complete YouTube Music client for Android using Metrolist-style WebView authentication**

## 🔐 AUTHENTICATION IMPLEMENTATION

This version implements the **exact same WebView authentication approach** used by Metrolist, based on the provided screenshots.

### 🛠️ How Authentication Works

#### **1. WebView Login Flow**
- **LoginActivity.kt** loads Google login page in WebView
- User completes normal Google authentication 
- After redirect to `music.youtube.com`, JavaScript extraction begins
- Cookies and tokens automatically captured and stored securely

#### **2. JavaScript Token Extraction**
```kotlin
// Extracts visitor data and sync ID from YouTube Music
webView.loadUrl("javascript:Android.onRetrieveVisitorData(window.yt.config_.VISITOR_DATA)")
webView.loadUrl("javascript:Android.onRetrieveDataSyncId(window.yt.config_.DATASYNC_ID)")
```

#### **3. InnerTube API Integration**
- Uses YouTube's internal **InnerTube API** with WEB_REMIX client
- All requests authenticated with extracted cookies/tokens
- Provides personalized content, playlists, recommendations

#### **4. Secure Storage**
- **EncryptedSharedPreferences** for all authentication data
- Visitor data, cookies, account info stored securely
- Token validation and refresh mechanisms

---

## 📱 FEATURES

### **🔓 Public Mode (No Authentication)**
- Browse public YouTube videos
- Search functionality  
- Trending content
- Basic video playback

### **🔒 Authenticated Mode (After Login)**
- **Personalized home feed** based on your music taste
- **Your music library** - playlists, liked songs, subscriptions
- **Personalized recommendations** using your listening history
- **Like/unlike videos** and **subscribe to channels**
- **Account management** with user profile display
- **Watch later** and **playlist management**

---

## 🏗️ ARCHITECTURE

### **Authentication Layer**
- `AuthenticationManager.kt` - Core auth logic and secure storage
- `LoginActivity.kt` - WebView-based login with JavaScript bridges
- `MainActivity.kt` - Auth check and routing

### **API Layer**  
- `InnerTubeClient.kt` - YouTube Music's internal API client
- `AuthenticatedNetworkUtils.kt` - Network layer with auth headers
- `AuthenticatedYouTubeExtractor.kt` - JSON and HTML parsing

### **UI Layer**
- `AuthenticatedHomeScreen.kt` - Enhanced UI with user profile
- `AuthenticatedVideoCard.kt` - Video cards with like/subscribe actions
- Material 3 design with authentication-aware theming

---

## 🚀 SETUP & USAGE

### **1. Build Project**
```bash
./gradlew assembleDebug
```

### **2. Install APK**
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### **3. Login Methods**

#### **A. WebView Login (Recommended)**
1. Open app → Login screen appears
2. Tap "Login with Google"
3. Complete Google authentication in WebView
4. Automatic redirect and token extraction
5. Enjoy personalized YouTube Music!

#### **B. Advanced Token Login**
1. Tap "Advanced Token Login" 
2. Paste authentication token manually
3. For power users who have tokens from other sources

---

## 🔧 KEY IMPLEMENTATION DETAILS

### **WebView Configuration**
```kotlin
webView.settings.apply {
    javaScriptEnabled = true
    domStorageEnabled = true 
    userAgentString = getBrowserUserAgent() // Mimic real browser
}
```

### **InnerTube Client Configuration**
```kotlin
val clientConfig = mapOf(
    "clientName" to "WEB_REMIX",
    "clientVersion" to "1.20250310.01.00", 
    "clientId" to "67"
)
```

### **Authentication Headers**
```kotlin
val headers = mapOf(
    "Cookie" to extractedCookies,
    "X-Goog-Visitor-Id" to visitorData,
    "User-Agent" to browserUserAgent
)
```

---

## ⚠️ IMPORTANT WARNINGS

### **Legal & Ethical**
- **Violates YouTube Terms of Service** - Use at your own risk
- **Educational/research purposes only** 
- **DO NOT publish on Google Play Store**
- Users assume all legal responsibility

### **Technical Risks**
- **Extremely fragile** - Breaks when YouTube updates
- **Constant maintenance required** as YouTube changes API
- **Detection risk** - Google may block this approach anytime
- **No official support** - Reverse-engineered implementation

### **Privacy & Security**  
- **Stores authentication data locally** on device
- **Uses real Google login** (not fake/phishing)
- **No data sent to third parties**
- **EncryptedSharedPreferences** for secure storage

---

## 🔄 MAINTENANCE REQUIREMENTS

This approach requires **active maintenance**:

### **Regular Updates Needed For:**
- YouTube website structure changes
- JavaScript variable name changes  
- InnerTube API endpoint modifications
- New anti-bot measures from Google
- Updated client version requirements

### **Signs It's Broken:**
- Login fails with errors
- No personalized content loading
- API requests return 403/401 errors
- Empty video lists despite authentication

---

## 📊 COMPARISON WITH ALTERNATIVES

| Approach | Pros | Cons |
|----------|------|------|
| **This (WebView Auth)** | Full personalization, Real login | Fragile, Maintenance-heavy |
| **NewPipe Style** | Stable, No auth needed | No personalization |
| **Official API** | Supported, Stable | Limited features, No music |

---

## 🧪 DEVELOPMENT NOTES

### **Testing Authentication**
- Use test Google account (not your main account)
- Monitor network requests for debugging
- Check Android logs for JavaScript extraction errors

### **Debugging Tips**
```kotlin
// Enable WebView debugging
WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

// Log authentication data
Log.d("Auth", "Visitor Data: " + authManager.getVisitorData())
```

---

## 🤝 CONTRIBUTING

Since this is educational/research code:
- **Document all changes** to authentication flow
- **Test thoroughly** on multiple devices
- **Update README** when YouTube changes break functionality
- **Share discoveries** about new YouTube anti-bot measures

---

## 📚 REFERENCES

- [Metrolist App Analysis](based-on-provided-screenshots)
- [YouTube InnerTube API Documentation](community-reverse-engineering)
- [Android WebView Security](https://developer.android.com/guide/webapps/webview)
- [Material 3 Design Guidelines](https://m3.material.io/)

---

## ⚖️ LICENSE

**Educational Use Only** - Not for redistribution or commercial use.

---

**Remember: This implementation works by reverse-engineering YouTube Music's web interface. It's a constant cat-and-mouse game with Google's engineers. Use responsibly and expect frequent maintenance.**
